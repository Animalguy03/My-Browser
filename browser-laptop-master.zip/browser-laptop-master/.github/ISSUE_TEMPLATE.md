<!--
Have you searched for similar issues? We have received a lot of feedback and bug reports that we have closed as duplicates. Before submitting this issue, please visit our community site for common ones: https://community.brave.com/c/common-issues
-->

### Description
<!--
[Description of the issue]
-->


### Steps to Reproduce
<!--
Please add a series of steps to reproduce the problem. See https://stackoverflow.com/help/mcve for in depth information on how to create a minimal, complete, and verifiable example.
-->

  1.
  2.
  3.


**Actual result:**
<!--
Please add screenshots if needed.
-->


**Expected result:**


**Reproduces how often:**
<!--
What percentage of the time does it reproduce?
-->


### Brave Version

**about:brave info:**
<!--
Please open about:brave, copy the version information, and paste it.
-->


**Reproducible on current live release:**
<!--
Is this a problem with the live build? It matters for triage reasons.
-->


### Additional Information
<!--
Any additional information, related issues, extra QA steps, configuration or data that might be necessary to reproduce the issue.
-->
